var searchData=
[
  ['t_5ffinalop',['t_finalop',['../classcontrol_1_1estructura.html#acf0a8f4823204237222d662133a366ad',1,'control::estructura']]],
  ['t_5fide',['t_IDE',['../classcontrol_1_1estructura.html#a54659e92c477f69e28531da2dd2aff94',1,'control::estructura']]],
  ['t_5fidl1',['t_IDL1',['../classcontrol_1_1estructura.html#a3a5842c2ea305ba78ce362f3e14cadf4',1,'control::estructura']]],
  ['t_5fidl2',['t_IDL2',['../classcontrol_1_1estructura.html#a5a1735c250c1e51420570b986d42e555',1,'control::estructura']]],
  ['tam',['tam',['../classregistro.html#a2fd424bb347f24f5273b214c00462d04',1,'registro.tam()'],['../classmultiplexor.html#a2fd424bb347f24f5273b214c00462d04',1,'multiplexor.tam()']]],
  ['tam_5fcamino',['tam_camino',['../classcte__tipos__nucleo__pkg.html#a8a1da23f170363a69878c31274efeba7',1,'cte_tipos_nucleo_pkg']]],
  ['tam_5fsecuencia',['tam_secuencia',['../classcte__tipos__nucleo__pkg.html#a204fd996894cab1e0243fe27c7d42c5b',1,'cte_tipos_nucleo_pkg']]]
];
