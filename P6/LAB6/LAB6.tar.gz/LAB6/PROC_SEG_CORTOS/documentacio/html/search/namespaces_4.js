var searchData=
[
  ['tipos_5fconstan_5fmemoria_5fi_5fpkg',['tipos_constan_memoria_I_pkg',['../namespacetipos__constan__memoria__I__pkg.html',1,'']]],
  ['tipos_5fconstan_5fmemoria_5fpkg',['tipos_constan_memoria_pkg',['../namespacetipos__constan__memoria__pkg.html',1,'']]]
];
