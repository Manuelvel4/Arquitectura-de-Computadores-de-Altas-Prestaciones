var searchData=
[
  ['ini_5fmem',['ini_mem',['../classinicializa__mem__pkg.html#ab537c62c5dc7ada3608ab5049ddf394a',1,'inicializa_mem_pkg.ini_mem()'],['../class__inicializa__mem__pkg.html#ab537c62c5dc7ada3608ab5049ddf394a',1,'_inicializa_mem_pkg.ini_mem()']]],
  ['ini_5fmem_5fi',['ini_mem_I',['../classinicializa__mem__I__pkg.html#a52495e694163bb94b100f7edc116c8a3',1,'inicializa_mem_I_pkg.ini_mem_I()'],['../class__inicializa__mem__I__pkg.html#a52495e694163bb94b100f7edc116c8a3',1,'_inicializa_mem_I_pkg.ini_mem_I()']]]
];
