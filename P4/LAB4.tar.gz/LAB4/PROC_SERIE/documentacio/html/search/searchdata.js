var indexSectionsWithContent =
{
  0: "_abcdefilmnoprstuw",
  1: "_abcdefimprst",
  2: "ciprt",
  3: "abcdefimprst",
  4: "abcdilmpst",
  5: "abcdefilmnoprstuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

